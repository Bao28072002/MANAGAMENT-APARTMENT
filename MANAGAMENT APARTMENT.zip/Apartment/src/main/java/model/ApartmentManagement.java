package model;

public class ApartmentManagement {

}
